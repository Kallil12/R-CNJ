Brasil Students Scholarship - Prouni - (2005-2019)
==================================================

Scholarships given by the brazilian Government based on the Prouni
Program

Essa aplicação é para apresentar a distribuição das bolsas do PROUNI. Os
dados vieram do Kaggle:
<https://www.kaggle.com/datasets/lfarhat/brasil-students-scholarship-prouni-20052019>

O número total de registros é 2692540. Você está recebendo uma amostra
com 5 estados e os 150 cursos mais frequentes neles. Dados filtrados
conforme descrito então no arquivo `./prouni_2005_2019-top150.csv`. Para
ter todos os dados, é só baixar do Kaggle.

Algumas funções para construção de gráficos estão prontas no
`./global.R`. Você deve construir o `./ui.R` e `server.R`.
