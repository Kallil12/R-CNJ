Esse é um arquivo markdown
==========================

Abaixo temos uma lista de compras:

* Arroz.
* Açucar.
* Azeite.
* Farinha.
* Feijão.

## É póssível incluir código

No arquivo markdown os códigos são renderizados de acordo com a
linguagem definida no *chunk*

```{r}
# Uma soma no R.
x <- 10
x + 2 + 1
```

```{sh}
# Para listar os arquivos com Bash.
ls -1
```
