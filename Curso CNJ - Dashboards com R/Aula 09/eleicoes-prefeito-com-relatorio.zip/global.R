#-----------------------------------------------------------------------
# Pacotes.

library(reactable)
library(htmltools)
library(sf)
library(readxl)
library(tidyverse)

#' #-----------------------------------------------------------------------
#' # Lê os arquivos preparados com o `create_assets.R`.
#'
#' tb <- readRDS("eleicao_prefeito.rds")
#' br_municipal <- readRDS("br_municipal.rds")
#'
#' str(tb)
#' str(br_municipal)
#'
#' # Lista para testes.
#' #' params <- list(ano_eleitoral = 2000,
#' #'                unidade_federativa = "PR")
#'
#' #' params <- list(ano_eleitoral = 2016,
#' #'                unidade_federativa = "MS")
#'
#' #-----------------------------------------------------------------------
#' # Aplica o filtro.
#'
#' if (!is.null(params$unidade_federativa)) {
#'     tb_estado <- tb %>%
#'         filter(Sigla == params$unidade_federativa)
#'     br_estado <- br_municipal %>%
#'         filter(abbrev_state == params$unidade_federativa)
#' } else {
#'     tb_estado <- tb
#'     br_estado <- br_municipal
#' }
#'
#' rm(tb, br_municipal)
#'
#' if (!is.null(params$ano_eleitoral)) {
#'     tb_estado <- tb_estado %>%
#'         filter(Ano == params$ano_eleitoral)
#' } else {
#'     tb_estado <- tb_estado
#' }
#'
#' br_centroid <- br_estado %>%
#'     st_centroid() %>%
#'     rename("centroid" = "geom")
#'
#' br_estado <- bind_cols(br_estado, br_centroid[, "centroid"])
#'
#' tb_estado <-
#'     left_join(tb_estado,
#'               select(br_estado, code_muni, geom, centroid),
#'               by = c("Codigo" = "code_muni"))
#' # str(tb_estado)
#'
#' # Tranfere o atributo que se perde no `inner_join()`.
#' attr(tb_estado, "sf_column") <- attr(br_estado, "sf_column")
#'
#' tb_estado <- tb_estado %>%
#'     mutate(Partido = reorder(factor(Partido), Partido, length),
#'            Partido_lump = Partido,
#'            Partido_lump = fct_lump_n(Partido_lump, n = 4,
#'                                      other_level = "Outros"),
#'            # Partido_lump = fct_reorder(Partido_lump, Partido_lump, length),
#'            Partido_lump = fct_infreq(Partido_lump),
#'            Partido_lump = fct_relevel(Partido_lump, "Outros", after = Inf)) %>%
#'     drop_na(Partido_lump)
#'
#' tb_estado %>%
#'     count(Partido_lump)
#'
#' # tb_estado$Partido_lump %>%
#' #     levels()
#'
#' tb_count <- tb_estado %>%
#'     count(Partido, sort = TRUE) %>%
#'     mutate(freq = 100 * n/sum(n))

#-----------------------------------------------------------------------
# Gráficos e tabelas.

make_barplot <- function(tb_count, params) {
    ggplot(data = tb_count,
           mapping = aes(y = Partido, x = n)) +
        geom_col() +
        geom_label(mapping = aes(label = sprintf("%0.1f%%", freq))) +
        labs(x = "Número de prefeituras",
             title = sprintf("Ano eleitoral de %s para %s",
                             params$ano_eleitoral,
                             params$unidade_federativa)) +
        expand_limits(x = c(NA, 1.1 * max(tb_count$n)))
}

#' make_barplot(tb_count, params)

make_cloropleth <- function(tb_estado, params) {
    ggplot() +
        geom_sf(data = tb_estado,
                mapping = aes(geometry = geom, fill = factor(Partido_lump)),
                color = "white",
                size = 0.15,
                show.legend = TRUE) +
        labs(subtitle = sprintf("Municípios conforme partido do prefeito eleito em %s",
                                params$ano_eleitoral),
             size = 8) +
        theme_minimal() +
        labs(fill = "Partido")
}

#' make_cloropleth(tb_estado, params)

make_table <- function(tb_count, tb_estado) {
    tbl <-
        reactable(tb_count,
                  pagination = FALSE,
                  columns = list(
                      n = colDef(
                          name = "Prefeituras",
                          defaultSortOrder = "desc",
                          cell = function(value) {
                              width <- paste0(value * 100 / max(tb_count$n), "%")
                              value <- format(value, big.mark = ",")
                              value <- format(value, width = 9, justify = "right")
                              bar <- div(
                                  class = "bar-chart",
                                  style = list(marginRight = "6px"),
                                  div(class = "bar",
                                      style = list(width = width,
                                                   backgroundColor = "#131991"))
                              )
                              div(class = "bar-cell",
                                  span(class = "number", value),
                                  bar)
                          }
                      ), # n
                      freq = colDef(
                          name = "Porcentagem",
                          defaultSortOrder = "desc",
                          cell = JS("function(cellInfo) {
                                     // Format as percentage
                                     const pct = (cellInfo.value).toFixed(1) + '%'
                                     // Pad single-digit numbers
                                     let value = pct.padStart(5)
                                     // Show % on first row only
                                     if (cellInfo.viewIndex > 0) {
                                       value = value.replace('%', ' ')
                                     }
                                     // Render bar chart
                                     return (
                                       '<div class=\"bar-cell\">' +
                                         '<span class=\"number\">' + value + '</span>' +
                                         '<div class=\"bar-chart\" style=\"background-color: #e1e1e1\">' +
                                           '<div class=\"bar\" style=\"width: ' + pct + '; background-color: #0a7350\"></div>' +
                                         '</div>' +
                                       '</div>'
                                     )
                                     }"),
                html = TRUE
                ) # freq
                ), # columns
                details = function(index) {
                    partido <- tb_count$Partido[index]
                    partido_data <- tb_estado[
                        tb_estado$Partido == partido,
                        c("Município"), drop = FALSE]
                    # htmltools::div(style = "padding: 16px",
                    #                reactable(partido_data, outlined = TRUE))

                    remainder <- length(partido_data$Município) %% 4
                    if (remainder > 0) {
                        y <- c(partido_data$Município, rep(NA_character_, 4 - remainder))
                    } else {
                        y <- c(partido_data$Município)
                    }
                    u <- as.data.frame(matrix(y, ncol = 4))
                    htmltools::div(style = "padding: 16px",
                                   reactable(u,
                                             defaultColDef = colDef(
                                                 header = function(value) "Município"),
                                             outlined = FALSE))
                }
                )
    return(tbl)
}

#' make_table(tb_count, tb_estado)

#-----------------------------------------------------------------------
