#-----------------------------------------------------------------------

library(rmarkdown)

# Criando diretório para
dir.create("./relatorios")
dir("./relatorios")

#-----------------------------------------------------------------------
# Gerando um relatório.

uf <- "MS"
ano <- 2000

rmarkdown::render("eleicoes_para_prefeito.Rmd",
                  output_file = sprintf("./relatorios/%s-%d", uf, ano),
                  params = list(unidade_federativa = uf,
                                ano_eleitoral = ano))

#-----------------------------------------------------------------------
# Correndo em loop.

tb_cond <- expand.grid(uf = c("MS", "PR", "MT"),
                       ano = c(1996, 2000),
                       KEEP.OUT.ATTRS = FALSE)
tb_cond

for (i in seq(nrow(tb_cond))) {
    uf <- tb_cond$uf[i]
    ano <- tb_cond$ano[i]
    rmarkdown::render("eleicoes_para_prefeito.Rmd",
                      output_file = sprintf("./relatorios/%s-%d", uf, ano),
                      params = list(unidade_federativa = uf,
                                    ano_eleitoral = ano))
}

#-----------------------------------------------------------------------
