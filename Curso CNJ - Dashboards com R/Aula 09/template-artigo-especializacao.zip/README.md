# template-dsbd-ufpr

Adaptação para o R do template disponibilizado pela UFPR para trabalho de conclusão do curso de Especialização em Data Science e Big Data.

Template original: https://gitlab.c3sl.ufpr.br/dsbd/tcc