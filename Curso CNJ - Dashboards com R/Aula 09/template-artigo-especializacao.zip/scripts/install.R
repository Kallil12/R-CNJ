if (!require(pacman)) install.packages("pacman"); library(pacman)

# Carrega os pacotes necessários
# p_load(nome_do_pacote) para pacotes do CRAN
# p_load_gh("nome_do_pacote") para pacotes do GitHub
p_load(kableExtra) # pacote obrigatório, não excluir esta linha!!!
p_load(tidyverse)

